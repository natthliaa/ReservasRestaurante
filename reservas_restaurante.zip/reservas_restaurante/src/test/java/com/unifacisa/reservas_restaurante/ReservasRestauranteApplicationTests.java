package com.unifacisa.reservas_restaurante;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservasRestauranteApplicationTests {

	@Test
	void contextLoads() {
	}

}
